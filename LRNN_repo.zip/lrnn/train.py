
def train(model, X, y):
    return model
